package com.example.chocoan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChocoanApplicationTests {

	@Test
	void contextLoads() {
	}

}
